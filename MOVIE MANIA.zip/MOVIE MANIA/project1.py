#importing modules
import pygame,sys,random  
#initialising pygame
pygame.init()
#displaying the screen
screen=pygame.display.set_mode([800,600])
#setting caption in the pygame window
pygame.display.set_caption("MOVIE MANIA")
#setting icon for pygame window
icon=pygame.image.load("MOVIE QUIZ.jpg")
pygame.display.set_icon(icon)
#introducing colors (R,G,B)
WHITE=(255,255,255)
BLACK=(0,0,0)
BLUE=(0,0,128)
GREEN=(0,255,0)
#loading background image
a=pygame.image.load('background.jpg')
#displaying the background image
screen.blit(a,(0,0))
#image for correct answer
ca=pygame.image.load('correct answer.jpg')
#image for wrong answer
wa=pygame.image.load('wrong answer.jpg')
#images to choose from
images=['ae dil hai mushkil.jpg','ashoka.jpg','bhag milkha bhag.jpg','besharam.jpg',
'billu barber.jpg','fitoor.jpg','badrinath ki dulhaniya.jpg','english vinglish.jpg','pk.jpg',
'rab ne bana di jodi.jpg','bajrangi bhaijan.jpg','bala.jpg','dilwale dulhaniya le jaenge.jpg',
'jab we met.jpg','kabhi khushi kabhi gam.jpg','kal ho naa ho.jpg','kedarnath.jpg',
'kesari.jpg','khoobsurat.jpg','luka chupi.jpg','manikarnika.jpg','naseeb.jpg','partner.jpg','queen.jpg',
'raazi.jpg','raone.jpg','sanju.jpg','sarbjit.jpg','sholay.jpg','special 26.jpg','tamasha.jpg','tevar.jpg',
'tiger zinda hai.jpg','war.jpg','yeh jawani hai diwani.jpg','hindi medium.jpg',
'jagga jasoos.jpg','mardaani.jpg','parineeta.jpg']
#random function load images
q=random.choice(images)
im=pygame.image.load(q)
l=0
#for text input
bfont=pygame.font.Font(None,48)
#string in which text should be entered
userinput=""
k=False
s=0
#Game loop
while True:
    for event in pygame.event.get():
        if(event.type==pygame.QUIT):
            l=1
            pygame.quit()
            sys.exit()
        else:
            if(event.type==pygame.KEYDOWN):
                if(event.key==pygame.K_BACKSPACE):
                    userinput=userinput[0:-1]
                if(event.key==pygame.K_RETURN):
                    if(userinput==q[:-4]):
                        k=True
                    else:
                        k=False
                        s=1
                else:
                    userinput=userinput+event.unicode  
    if(k):#checking if answer is correct
        screen.blit(ca,(0,0)) 
        pygame.display.flip() 
    elif(s==1):
        screen.fill(WHITE)
        screen.blit(wa,(0,0)) 
        pygame.display.flip()
    else:
        #rendering for text
        texr=bfont.render(userinput,True,WHITE)
        #displaying the input
        screen.blit(texr,(250,400))
        #displaying the image on screen
        screen.blit(im,(250,30))
        #to update the screen display
        pygame.display.update()    
      

